NOTE: node_modules removed

0. Up-to-date version of node.js and React
1. Enter: npm install
2. Enter: npm start