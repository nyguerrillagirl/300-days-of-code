#ifndef VECTOR2D_H
#define VECTOR2D_H


class Vector2d
{
    public:
        Vector2d() {}
        virtual ~Vector2d() {}

    protected:

    private:
};

#endif // VECTOR2D_H
