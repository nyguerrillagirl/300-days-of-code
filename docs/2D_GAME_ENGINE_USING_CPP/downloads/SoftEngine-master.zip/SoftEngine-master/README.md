## SoftEngine
source code for building a positronic demolecularizer.   
intented goal: break the planet in two.   
usage: empty your head, cross the streams and hold your breath.   
miracle should occur shortly after.   
also: cpp, sdl2, tilemap based game engine   

